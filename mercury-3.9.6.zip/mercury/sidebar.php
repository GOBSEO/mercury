	<?php
		if ( is_active_sidebar( 'right-sidebar' ) ) {
			dynamic_sidebar( 'right-sidebar' );
		}
	?>